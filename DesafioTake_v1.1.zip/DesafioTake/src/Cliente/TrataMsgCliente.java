/**
 * Classe de Tratamento de Mensagens do cliente
 * 
 * Classe de tratamento de mensagens provenientes dos clientes/usu�rios do chat
 */
package Cliente;

import java.io.InputStream;
import java.util.Scanner;

import Servidor.Servidor;

/**
 * @author Rafael Alves
 * 
 * Baseado em estudos nos f�runs de internet
 * 
 * Alguns sites de refer�ncias para o trabalho: 
 * https://www.caelum.com.br/apostila-java-orientacao-objetos/
 * https://stackoverflow.com/questions/
 * https://www.devmedia.com.br/forum/
 * https://www.guj.com.br/
 * 
 */
public class TrataMsgCliente implements Runnable {

	/**
	 * Vari�veis utilizadas somente na classe
	 */
	private InputStream cliente;
	private Servidor servidor;

	/**
	 * M�todo construtor
	 * @param cliente
	 * @param servidor
	 */
	public TrataMsgCliente(InputStream cliente, Servidor servidor) {
		this.cliente = cliente;
		this.servidor = servidor;
	}

	/**
	 * M�todo de execu��o, que realiza o Scan das mensagens dos clientes e as tratas, chamando o distribuidor que as envia para o chat. 
	 */
	public void run() {
		Scanner scan = new Scanner(this.cliente);
		while (scan.hasNextLine()) {
			servidor.distribuiMensagem(scan.nextLine());
		}
		scan.close();
	}
}
