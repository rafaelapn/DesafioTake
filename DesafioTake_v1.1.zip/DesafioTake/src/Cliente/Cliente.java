/**
 * Classe Cliente
 *  
 * Classe que � respons�vel pela inicia��o do cliente e conex�o com o servidor de chat
 * Se executar v�rias vezes, ser� poss�vel conectar m�ltiplos clientes ao mesmo servidor
 */
package Cliente;

import java.io.IOException;
import Servidor.RecebeMsgServidor;
import java.io.PrintStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Rafael Alves
 * 
 * Baseado em estudos nos f�runs de internet
 * 
 * Alguns sites de refer�ncias para o trabalho: 
 * https://www.caelum.com.br/apostila-java-orientacao-objetos/
 * https://stackoverflow.com/questions/
 * https://www.devmedia.com.br/forum/
 * https://www.guj.com.br/
 * 
 */
public class Cliente {

	private String host;
	private int porta;
	private String apelido;
	private ArrayList<String> listaApelidos;

	/**
	 * Construtor
	 * @param host
	 * @param porta
	 */
	public Cliente(String host, int porta) {
		this.host = host;
		this.porta = porta;
		this.apelido = apelido;
		this.listaApelidos = new ArrayList<>();
	}
	
	/**
	 * Classe Main
	 * @param args
	 * @throws UnknownHostException
	 * @throws IOException
	 */
	public static void main(String[] args) throws UnknownHostException, IOException {
		/**
		 * Inicia cliente
		 * Sempre como localhost, devido ao fato de n�o estarmos em servidor HTTP com rede para gerar Ip's para cada cliente.
		 * Porta padr�o tamb�m 12345, devido a somente a did�tica do exerc�cio
		 */
		new Cliente("127.0.0.1", 12345).executa();
	}

	/**
	 * M�todo de execu��o, que cria sempre os clientes e teclado de scan, al�m das sa�das do teclado em tela.
	 * @throws UnknownHostException
	 * @throws IOException
	 */
	public void executa() throws UnknownHostException, IOException {

		try{
			/**
			 * Cria e Mostra qual cliente conectou
			 */
			Socket cliente = new Socket(this.host, this.porta);
			System.out.println("O cliente se conectou ao servidor: "+cliente.toString());
			
			Scanner teclado = new Scanner(System.in);
			PrintStream saida = new PrintStream(cliente.getOutputStream());
			
			System.out.println("Seja bem vindo ao Chat!");
			System.out.println("...");
			System.out.println("Fun��es do chat:");
			System.out.println("/Apelido: Fun��o Inicial do Chat para inclus�o do apelido do usu�rio:");
			System.out.println("/Sair: Sair do Chat");
			System.out.println("/Help: Ver fun��es do Chat");
			System.out.println("...");
			System.out.println("Digite abaixo o seu apelido para o server:");
			System.out.println("/Apelido:");
			
			/**
			 * Recebe a mensagem do servidor e starta o cliente
			 */
			RecebeMsgServidor r = new RecebeMsgServidor(cliente.getInputStream());
			new Thread(r).start();
			
			/**
			 * Enquanto tiver mensagem na via teclado, a fun��o printa na tela a mensagem do cliente
			 */
			while (teclado.hasNextLine()) {
				/**
				 * Envio de mensagem p�blica para o chat
				 */
				saida.println(teclado.nextLine());
				
				if(teclado.findInLine("/Apelido: ") != null) {
					this.incluiApelido(teclado.toString());
				}
				
				/**
				 * Fun��o para sair do chat
				 */
				if (teclado.findInLine("/Sair") != null) {
					break;
				}
				/**
				 * Fun��o de Help para verificar fun��es dispon�veis no chat
				 */
				if (teclado.findInLine("/Help") != null) {
					System.out.println("Fun��es do chat:");
					System.out.println("/Apelido: Fun��o Inicial do Chat para inclus�o do apelido do usu�rio:");
					System.out.println("/Help: Ver fun��es do Chat");
					System.out.println("/Sair: Sair do Chat");
				}
			}
			cliente.close();
			teclado.close();
			saida.close();
		}catch (UnknownHostException e) {
			e.printStackTrace();
		}catch (IOException e1) {
			e1.printStackTrace();
		}
	}
	
	/**
	 * M�todo para Incluir Apelidos na Lista de Apelidos do Chat
	 * @param apelido
	 * @return
	 */
	public boolean incluiApelido(String apelido) {
		
		boolean incluiu = true;
				
		int i = 0;
		for (i = 0; i < listaApelidos.size(); i++) {
			if (apelido != listaApelidos.get(i).toString()) {
				this.listaApelidos.add(apelido);
			}else{
				System.out.println("Apelido j� est� em uso...Tente outro apelido!");
				break;
			}
		}
		
		return incluiu;
	}

}
