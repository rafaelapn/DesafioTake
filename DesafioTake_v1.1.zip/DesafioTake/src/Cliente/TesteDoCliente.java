/**
 * Classe de teste unit�rio da classe @Cliente
 */
package Cliente;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.net.UnknownHostException;

import org.junit.jupiter.api.Test;

/**
 * @author Rafael Alves
 * 
 * Classe de teste unit�rio da classe @Cliente
 *
 */
class TesteDoCliente {

	@Test
	void test() throws UnknownHostException, IOException {
		try {
			Cliente cliente = new Cliente("127.0.0.1",12345);
			cliente.executa();
			
			assertTrue(true, "Cliente Funcionou");
		} catch (UnknownHostException e) {
			fail("Cliente N�o funcionou: /n");
			e.printStackTrace();
		} catch (IOException e) {
			fail("Cliente N�o funcionou: /n");
			e.printStackTrace();
		}		
	}

}
