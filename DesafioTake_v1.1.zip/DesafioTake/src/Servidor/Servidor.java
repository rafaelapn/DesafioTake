/**
 * Classe servidor
 * 
 * Inicia o servidor via conex�o Socket nativo.
 * Setando uma porta padr�o 12345 para o servidor, somente como did�tica
 * Limite de tempo do servidor aberto = long de 1536259 == 25:36:259
 */
package Servidor;

import java.io.IOException;
import java.net.ServerSocket;
import java.io.PrintStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
//import java.util.Scanner;

import Cliente.TrataMsgCliente;

/**
 * @author Rafael Alves
 * 
 * Baseado em estudos nos f�runs de internet
 * 
 * Alguns sites de refer�ncias para o trabalho: 
 * https://www.caelum.com.br/apostila-java-orientacao-objetos/
 * https://stackoverflow.com/questions/
 * https://www.devmedia.com.br/forum/
 * https://www.guj.com.br/
 * 
 */
public class Servidor {

	private int porta;
	private List<PrintStream> clientes;
	public String apelido;

	/**
	 * Construtor para setar vari�veis de porta e array de clientes do chat
	 * @param porta
	 */
	public Servidor(int porta) {
		this.porta = porta;
		this.clientes = new ArrayList<PrintStream>();
	}

	/**
	 * Main que inicia o processo de chamada ao m�todo de inicia��o do servidor do chat
	 * @param args
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public static void main(String[] args) throws IOException, InterruptedException {
		/**
		 * Iniciar o servidor
		 */
		Servidor server = new Servidor(12345);
		server.executa();
	}

	/**
	 * M�todo que executa o start do servidor e manter aberta a porta de conex�o de novos usu�rios ao chat
	 * @throws IOException
	 * @throws InterruptedException
	 */
	public void executa() throws IOException, InterruptedException {

		ServerSocket servidor = null;

		try{
			servidor = new ServerSocket(this.porta);

			System.out.println("Servidor de Chat Online!/n");
			System.out.println("Porta "+ this.porta +" aberta!");

			/**
			 * Seta tempo para manter o servidor ativo
			 */
			/*long time = 1536259;
			Thread threadServidor = new Thread();
			System.out.println("Tempo de limite do servidor "+ (new SimpleDateFormat("mm:ss:SSS")).format(new Date(time)) +" aberto!");
			 */
			/**
			 * Valida sempre para verificar se o tempo da thread est� ativa, para manter o aceite a novas conex�es
			 */
			Socket cliente = null;
			//Scanner s = null;

			//while (threadServidor.isAlive()) {
			while (true){

				/**
				 *  Aceita os clientes para o servidor
				 */
				cliente = servidor.accept();
				System.out.println("Nova conex�o com o cliente IP: " + cliente.getInetAddress().getHostAddress());

				/**
				 * Adiciona o cliente ao array chat
				 */
				//this.clientes.add(cliente);
				PrintStream ps = new PrintStream(cliente.getOutputStream());
				this.clientes.add(ps);

				/**
				 * Aciona classe de tratamento de mensagens vindas de cada cliente.
				 * Via Thread para tratar m�ltiplos clientes
				 */
				TrataMsgCliente tc = new TrataMsgCliente(cliente.getInputStream(), this);
				new Thread(tc).start();

				/*s = new Scanner(cliente.getInputStream());
		        while (s.hasNextLine()) {
		            System.out.println(s.nextLine());
		        }*/
			}
			/**
			 * Caso o tempo do server tenha expirado, fecha a conex�o.
			 */
			//threadServidor.sleep(time);
			/*servidor.close();
			cliente.close();
			s.close();
			System.out.println("Fechou o Servidor");*/
		}catch (IOException e) {
			e.printStackTrace();
		}/*catch (InterruptedException e1) {
			e1.printStackTrace();
		}*/
	}

	/**
	 * M�todo para tratar e redistribuir as mensagens vindas dos inputs de teclado dos clientes conectados ao server
	 * @param clienteQueEnviou
	 * @param msg
	 */
	public void distribuiMensagem(String msg) {
		for (PrintStream cliente : this.clientes) {
			cliente.println(msg);
		}
	}

}
