/**
 * Classe de recebimento de mensagens do server
 * 
 * Classe de tratamento de mensagens provenientes do servidor.
 */
package Servidor;

import java.io.InputStream;
import java.util.Scanner;

/**
 * @author Rafael Alves
 * 
 * Baseado em estudos nos f�runs de internet
 * 
 * Alguns sites de refer�ncias para o trabalho: 
 * https://www.caelum.com.br/apostila-java-orientacao-objetos/
 * https://stackoverflow.com/questions/
 * https://www.devmedia.com.br/forum/
 * https://www.guj.com.br/
 * 
 */
public class RecebeMsgServidor implements Runnable {

	/**
	 * Vari�veis
	 */
	private InputStream servidor;

	/**
	 * Construtor
	 * @param servidor
	 */
	public RecebeMsgServidor(InputStream servidor) {
		this.servidor = servidor;
	}

	/**
	 * Classe de execu��o, recebe mensagem proveniente do servidor via Scanner e print a mensagem no chat.
	 */
	public void run() {
		Scanner scan = null;
		try{
			scan = new Scanner(this.servidor);
			
			while(scan.hasNextLine()) {
				System.out.println(scan.nextLine());
			}
		}catch(Exception e) {
			e.printStackTrace();
			scan.close();
		}
	}

}
