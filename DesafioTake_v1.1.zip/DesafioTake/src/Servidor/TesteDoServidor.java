/**
 * Classe de valida��o unit�ria da Classe @Servidor
 */
package Servidor;

import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;

import org.junit.jupiter.api.Test;

/**
 * @author Rafael Alves
 * 
 * Classe de valida��o unit�ria da Classe @Servidor
 *
 */
class TesteDoServidor {

	@Test
	void test() throws IOException, InterruptedException {
		
			try {
				Servidor servidor = new Servidor(12345);
				servidor.executa();
				
				assertTrue(true, "Servidor Funcionou");
			} catch (IOException e) {
				fail("Servidor N�o funcionou: /n");
				e.printStackTrace();
			} catch (InterruptedException e) {
				fail("Servidor N�o funcionou: /n");
				e.printStackTrace();
			}	
	}

}
