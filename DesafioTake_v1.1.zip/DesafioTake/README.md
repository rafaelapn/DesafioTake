# DesafioTake

Primeiramente, obrigado pela oportunidade, foi muito divertido relembrar conceitos e voltar a desenvolver.

## Chat Desktop - Vers�o 1.0
> Sistema desenvolvido para o processo de sele��o para vaga na empresa Take Blip

O Sistema de Chat foi desenvolvido em Java, utilizando Sockets para a comunica��o entre o Servidor e Clientes.

## Instala��o

O programa ficou desenvolvido para rodar diretamente em uma IDE. Este foi desenvolvido no Eclipse:
Version: 2020-09 (4.17.0)
Build id: 20200910-1200

```shell
DesafioTake.zip
```
Baixe o .zip e abra o source no Eclipe, como New Java Project.

## Pacotes e Classes do programa

O sistema foi desenvolvido em 2 Pacotes:

```shell
package Cliente;
class Cliente.java
class TrataMsgCliente.java
class TesteDoCliente.java /JUnit

package Servidor;
class Servidor.java
class RecebeMsgServidor.java
class TesteDoServidor.java /JUnit
```

### Descri��o das Classes

#### package Cliente;
- class Cliente.java
  - Classe que � respons�vel pela inicia��o do cliente e conex�o com o servidor de chat.
  - Se executar v�rias vezes, ser� poss�vel conectar m�ltiplos clientes ao mesmo servidor.
- class TrataMsgCliente.java
  - Classe de Tratamento de Mensagens do cliente.
  - Classe de tratamento de mensagens provenientes dos clientes/usu�rios do chat.
- class TesteDoCliente.java /JUnit
  - Classe de teste unit�rio da classe @Cliente

#### package Servidor;
- class Servidor.java
  - Inicia o servidor via conex�o Socket nativo.
  - Setando uma porta padr�o 12345 para o servidor, somente como did�tica.
  - Limite de tempo do servidor aberto = long de 1536259 == 25:36:259.
- class RecebeMsgServidor.java
  - Classe de recebimento de mensagens do server
  - Classe de tratamento de mensagens provenientes do servidor.
- class TesteDoServidor.java /JUnit
  - Classe de valida��o unit�ria da Classe @Servidor

## Reposit�rio

O reposit�rio utilizado para o projeto foi o Git.
E criado acesso e uma release no GitHub rafaelapn/DesafioTake.

## Refer�ncias para o trabalho

Como trabalho pessoal, para fins espec�ficos, foram utilizadas refer�ncias e exemplos de alguns sites importantes de coding, conforme abaixo.

- https://www.caelum.com.br/apostila-java-orientacao-objetos/
- https://stackoverflow.com/questions/
- https://www.devmedia.com.br/forum/
- https://www.guj.com.br/

## Licen�a

GNU. Trabalho feito para fins espec�ficos e de avalia��o espec�fica para a empresa Take Blip, para processo seletivo.
De n�o comercializa��o.Aplicação DesafioTake

Desenvolvida por Rafael Alves, com base em referências na internet, tais como os abaixo, e conhecimentos do passado.
https://www.caelum.com.br/apostila-java-orientacao-objetos/
https://stackoverflow.com/questions/
https://www.devmedia.com.br/forum/
https://www.guj.com.br/

------------

Foi desenvolvida a aplicação de Chat Online.
Com um servidor e possibilidade de mais de uma instância de clientes.

------------

A Solução é composta de 2 pacotes, com suas classes 

Cliente
Servidor

Com suas classes respectivas:

Cliente:
